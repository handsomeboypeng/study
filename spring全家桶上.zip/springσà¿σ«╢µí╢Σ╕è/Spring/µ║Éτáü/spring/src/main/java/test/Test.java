package test;

import com.perker.entity.Student;

public class Test {
    public static void main(String [] args) {
        //传统开发方式手动创建对象
        Student student = new Student();
        System.out.println(student);


    }
}
