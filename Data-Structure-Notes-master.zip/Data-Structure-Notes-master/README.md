# Data-Structure-Notes
MOOC_数据结构 浙江大学 陈越 何钦铭
  
PPT来源：中国大学MOOC网  
Notes:随堂笔记（本人所写）  
PTA_Exercise: 随堂拼题A练习题答案，C语言（本人所写）  
