#include "commentConvert.h"

int main()
{

	printf("Start convert...\n");
	convertBagin();
	printf("Done...\n");

	system("pause");
	return 0;
}