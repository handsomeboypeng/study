# C语言课程设计：贪食蛇

## 使用说明

1. 复制源码到VSCode或其他IDE
2. 点击编译按钮，编译生成.exe文件，或者使用gcc snake.c -o snake生成
3. 点击运行snake.exe
4. A D W S为方向控制