package com.southwind.jpa.repository;

import com.southwind.jpa.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JpaUserRepository extends JpaRepository<User,Integer> {
    public User findByUsername(String username);
}
