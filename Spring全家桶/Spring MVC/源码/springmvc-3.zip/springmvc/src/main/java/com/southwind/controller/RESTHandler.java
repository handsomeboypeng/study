package com.southwind.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/rest")
public class RESTHandler {

//    @RequestMapping(value = "/find",method = RequestMethod.GET)
    @GetMapping("/find")
    @ResponseBody
    public String find(){
        return "Hello";
    }

    @PostMapping("/save")
    public void save(){

    }

    @PutMapping("/update")
    public void update(){

    }

    @DeleteMapping("/delete")
    public void delete(){

    }

}
