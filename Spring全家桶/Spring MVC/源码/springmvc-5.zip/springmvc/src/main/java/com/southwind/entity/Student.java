package com.southwind.entity;

import lombok.Data;

@Data
public class Student {
    private String name;
    private String password;
}
