package com.southwind.entity2;

import lombok.Data;

@Data
public class Address {
    private Integer id;
    private String name;
}
