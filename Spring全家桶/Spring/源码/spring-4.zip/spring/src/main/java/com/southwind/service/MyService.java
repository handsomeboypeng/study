package com.southwind.service;

public interface MyService {
    public String doService(Double score);
}
