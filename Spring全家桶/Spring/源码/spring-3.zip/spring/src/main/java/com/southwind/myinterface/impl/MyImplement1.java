package com.southwind.myinterface.impl;

import com.southwind.myinterface.MyInterface;
import org.springframework.stereotype.Component;

@Component
public class MyImplement1 implements MyInterface {
}
