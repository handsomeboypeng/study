package com.southwind.repository;

public interface MyRepository {
    public String doRepository(Double score);
}
