package com.southwind.myinterface;

public interface MyInterface {
}
