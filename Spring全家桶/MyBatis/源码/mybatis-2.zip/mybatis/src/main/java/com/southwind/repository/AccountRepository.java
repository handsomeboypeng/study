package com.southwind.repository;

import com.southwind.entity.Account;

public interface AccountRepository {
    public Account findById(Integer id);
}
