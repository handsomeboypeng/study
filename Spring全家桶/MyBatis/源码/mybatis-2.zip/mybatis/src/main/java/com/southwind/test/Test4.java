package com.southwind.test;

import com.southwind.entity.Account;
import com.southwind.entity.Classes;
import com.southwind.entity.Course;
import com.southwind.entity.Student;
import com.southwind.repository.AccountRepository;
import com.southwind.repository.ClassesRepository;
import com.southwind.repository.CourseRepository;
import com.southwind.repository.StudentRepository;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.InputStream;

public class Test4 {
    public static void main(String[] args) {
        InputStream inputStream = Test2.class.getClassLoader().getResourceAsStream("config.xml");
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
//        StudentRepository studentRepository = sqlSession.getMapper(StudentRepository.class);
//        Student student = studentRepository.findById(1);
//        System.out.println(student);
//        ClassesRepository classesRepository = sqlSession.getMapper(ClassesRepository.class);
//        Classes classes = classesRepository.findById(1);
//        System.out.println(classes);

//        AccountRepository accountRepository = sqlSession.getMapper(AccountRepository.class);
//        Account account = accountRepository.findById(1);
//        System.out.println(account);

        CourseRepository courseRepository = sqlSession.getMapper(CourseRepository.class);
        Course course = courseRepository.findById(1);
        System.out.println(course);

    }
}
