package com.southwind.test;

import com.southwind.entity.People;
import com.southwind.repository.PeopleRepository;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.InputStream;
import java.util.List;

public class Test2 {
    public static void main(String[] args) {
        InputStream inputStream = Test2.class.getClassLoader().getResourceAsStream("config.xml");
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //获取实现了自定义接口的代理对象
        PeopleRepository peopleRepository = sqlSession.getMapper(PeopleRepository.class);
//        People people = new People();
//        people.setName("小明");
//        people.setMoney(Double.parseDouble("666"));
//        int row = peopleRepository.save(people);
//        People people = peopleRepository.findById(6);
//        System.out.println(people);
//        people.setName("小红");
//        people.setMoney(Double.parseDouble("800"));
//        peopleRepository.update(people);
//        System.out.println(row);
//        peopleRepository.deleteById(6);
//        sqlSession.commit();
//        List<People> list = peopleRepository.findAll();
//        for(People people:list){
//            System.out.println(people);
//        }

        People people = peopleRepository.findById2(1);
        System.out.println(people);
        People people1 = peopleRepository.findByName("小明");
        System.out.println(people1);
        People people2 = peopleRepository.findByIdAndName(7,"小明");
        System.out.println(people2);
        sqlSession.close();
    }
}
