package com.southwind.repository;

import com.southwind.entity.MyClass;

public interface MyClassRepository {
    public MyClass findById(Integer id);
}
