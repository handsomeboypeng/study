package com.southwind.entity;

import lombok.Data;

@Data
public class MyClass {
    private Integer id;
    private String name;
}
