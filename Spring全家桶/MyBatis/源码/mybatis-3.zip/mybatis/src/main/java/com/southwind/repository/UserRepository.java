package com.southwind.repository;

import com.southwind.entity.User;

public interface UserRepository {
    public User findByUser(User user);
    public int update(User users);
}
