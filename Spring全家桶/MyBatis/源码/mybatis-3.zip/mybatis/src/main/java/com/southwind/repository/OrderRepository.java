package com.southwind.repository;

import com.southwind.entity.Order;

public interface OrderRepository {
    public Order findById(Integer id);
}
