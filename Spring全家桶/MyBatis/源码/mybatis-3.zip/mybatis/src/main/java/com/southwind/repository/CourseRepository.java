package com.southwind.repository;

import com.southwind.entity.Course;

public interface CourseRepository {
    public Course findById(Integer id);
}
