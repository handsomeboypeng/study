package com.southwind.repository;

import com.southwind.entity.People;

import java.util.List;

public interface PeopleRepository {
    public int save(People people);
    public int deleteById(Integer id);
    public int update(People people);
    public People findById(Integer id);
    public List<People> findAll();
    public People findById2(int id);
    public People findByName(String name);
    public People findByIdAndName(Integer id,String name);
    public Integer count();
    public String findNameById(Integer id);
}
